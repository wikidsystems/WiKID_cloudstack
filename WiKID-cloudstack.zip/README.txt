Prototype WiKID User Authenticator module for CloudStack

This module was compiled against libraries from CloudStack-oss-3.0.2-1-rhel6.2.tar.gz

Configuration properties must be placed in: /etc/WiKID/cloudstack.properties

The WiKIDUserAuthenticator.jar contains a sample properties file